## Summary
- What & Why:
- Linked sections (docs/plan.md):
- Related .mdc rules:

## Tests
- Unit/Integration: links or summary
- Result: ✅/❌

## Safety
- Thresholds changed? evidence logged? ✅/❌
