# Decision Log (append-only)
- 2025-09-29: 초기 thresholds.json 채택(값 …), 근거(모델/출처 링크) 기록
