# Plan
Sections: forecast-ingest, tide-merge, window-link, ioi-decision, map-ui
Done-When: 각 섹션 테스트 통과 + decision-log 기록
